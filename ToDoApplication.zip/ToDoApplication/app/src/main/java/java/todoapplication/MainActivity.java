package java.todoapplication;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;


import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class MainActivity extends AppCompatActivity {
    ListView listView;
    ArrayList<String> arrayList;
    ArrayAdapter<String> arrayAdapter;
    String messageText;
    int position;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = (ListView) findViewById(R.id.listView);
        arrayList = new ArrayList<>();
        arrayAdapter =new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,arrayList);
        listView.setAdapter(arrayAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent();
                intent.setClass(MainActivity.this, EditMessageActivity.class);
                intent.putExtra(IntentConstraints.INTENT_MESSAGE_DATA,arrayList.get(position).toString());
                intent.putExtra(IntentConstraints.INTENT_ITEM_POSITION,position);
                startActivityForResult(intent,IntentConstraints.INTENT_REQUEST_CODE_TWO);

            }
        });
        try{
            Scanner sc = new Scanner(openFileInput("Todo.txt"));
            while(sc.hasNextLine()){
                String data = sc.nextLine();
                arrayAdapter.add(data);
            }
            sc.close();
        }catch(FileNotFoundException e){
            e.printStackTrace();
        }
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View view, ContextMenu.ContextMenuInfo menuInfo) {
        menu.setHeaderTitle("What would ou like to do");
        String options[]={"Delete","Cancel"};
        for(String option : options){
            menu.add(option);
        }
    }

    @Override
    public void onBackPressed() {
        try {
            PrintWriter pw =  new PrintWriter(openFileOutput("Todo.txt" , Context.MODE_PRIVATE));
            for(String data : arrayList){
                pw.println(data);
            }
            pw.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        finish();
    }

    public void onClick(View view) {
        Intent intent = new Intent();
        intent.setClass(MainActivity.this, EditFieldClass.class);
        startActivityForResult(intent,IntentConstraints.INTENT_REQUEST_CODE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(requestCode == IntentConstraints.INTENT_REQUEST_CODE){
        messageText = data.getStringExtra(IntentConstraints.INTENT_MESSAGE_FIELD);
        arrayList.add(messageText);
        arrayAdapter.notifyDataSetChanged();
        }
        else if(requestCode == IntentConstraints.INTENT_REQUEST_CODE_TWO){
            messageText = data.getStringExtra(IntentConstraints.INTENT_CHANGED_MESSAGE);
            position = data.getIntExtra(IntentConstraints.INTENT_ITEM_POSITION,-1);
            arrayList.remove(position);
            arrayList.add(position,messageText);
            arrayAdapter.notifyDataSetChanged();
        }
    }
}
